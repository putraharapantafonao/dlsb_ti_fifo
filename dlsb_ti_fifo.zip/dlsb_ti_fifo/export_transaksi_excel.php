<?php
require 'auth.php';
require 'koneksi.php';

$role = $_SESSION['role'] ?? '';
if ($role !== 'admin') {
    die("Akses ditolak.");
}

$mode  = $_GET['mode']  ?? 'range';
$start = $_GET['start'] ?? '';
$end   = $_GET['end']   ?? '';
$bulan = $_GET['bulan'] ?? '';

$where = "1=1";

if ($mode === 'range') {
    if ($start && $end) {
        $start_safe = mysqli_real_escape_string($conn, $start);
        $end_safe   = mysqli_real_escape_string($conn, $end);
        $where      = "DATE(p.tgl_pinjam) BETWEEN '$start_safe' AND '$end_safe'";
        $label      = "Periode $start s.d. $end";
    } else {
        die("Parameter tanggal tidak lengkap.");
    }

} elseif ($mode === 'month') {

    if ($bulan) {
        $bulan_safe = mysqli_real_escape_string($conn, $bulan);
        $where      = "DATE_FORMAT(p.tgl_pinjam, '%Y-%m') = '$bulan_safe'";
        $label      = "Bulan: " . date('F Y', strtotime($bulan.'-01'));
    } else {
        die("Parameter bulan tidak lengkap.");
    }

} else {
    $label = "Semua Periode";
}

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Laporan_Transaksi_".date('Ymd_His').".xls");

$sql = "
SELECT 
    p.id_pinjam,
    p.nim,
    m.nama AS nama_mhs,
    p.kelas_mk,
    p.nama_dosen,
    b.nama_barang,
    p.jumlah,
    p.tgl_pinjam,
    p.tgl_kembali_real,
    p.status,
    p.keterangan
FROM peminjaman p
JOIN mahasiswa m ON p.nim = m.nim
JOIN barang b    ON p.id_barang = b.id_barang
WHERE $where
ORDER BY p.tgl_pinjam ASC, p.id_pinjam ASC
";

$result = mysqli_query($conn, $sql);
?>

<html>
<body>

<h2 style="text-align:center;">Laporan Transaksi Peminjaman Barang</h2>
<h4 style="text-align:center;"><?php echo $label; ?></h4>
<p style="text-align:center;">DLSB-TI FIFO • Jurusan Teknik Informatika • Universitas Malikussaleh</p>
<br>

<table border="1" cellspacing="0" cellpadding="5">
    <tr style="background:#e0e0e0; font-weight:bold;">
        <td>No</td>
        <td>ID</td>
        <td>NIM</td>
        <td>Nama Mahasiswa</td>
        <td>Kelas / MK</td>
        <td>Dosen Pengampu</td>
        <td>Barang</td>
        <td>Jumlah</td>
        <td>Waktu Pinjam</td>
        <td>Waktu Kembali</td>
        <td>Status</td>
        <td>Keterangan</td>
    </tr>

<?php
$no = 1;
while ($row = mysqli_fetch_assoc($result)) {
?>
<tr>
    <td><?php echo $no++; ?></td>
    <td><?php echo $row['id_pinjam']; ?></td>
    <td><?php echo $row['nim']; ?></td>
    <td><?php echo $row['nama_mhs']; ?></td>
    <td><?php echo $row['kelas_mk']; ?></td>
    <td><?php echo $row['nama_dosen']; ?></td>
    <td><?php echo $row['nama_barang']; ?></td>
    <td><?php echo $row['jumlah']; ?></td>
    <td><?php echo $row['tgl_pinjam']; ?></td>
    <td><?php echo $row['tgl_kembali_real']; ?></td>
    <td><?php echo strtoupper($row['status']); ?></td>
    <td><?php echo $row['keterangan']; ?></td>
</tr>
<?php } ?>

</table>

</body>
</html>
