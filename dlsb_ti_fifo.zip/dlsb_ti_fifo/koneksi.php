<?php
// koneksi.php
$host = "localhost";
$user = "root";      // default XAMPP
$pass = "";          // default XAMPP
$db   = "dlsb_ti_fifo";  // nama database

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}
?>
